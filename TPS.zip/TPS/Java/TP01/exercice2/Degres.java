import java.util.Scanner;

public class Degres {

  public static void main(String[] args) {
    // TODO Auto-generated method stub

    Scanner sc= new Scanner(System.in);
    
    System.out.println("Veuillez entrer la temperature en degre");
    double temperature_degre=sc.nextDouble();
     
    double temperature_kelvin=temperature_degre + 273.13;
    
    System.out.println("On part du principe que tempKelvin=tempDegre + 273.13");
    System.out.println(":On obtient donc : " +temperature_kelvin);
    
    System.out.println("L'unite est le Kelvin");
    
  }

}
